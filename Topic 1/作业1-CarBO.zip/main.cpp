#include <iostream>
#include <vector>
#include <string>
#include "opencv2/highgui.hpp"
#include <iterator>

int main(int argc, char** argv) {

    cv::String filepath = "../../rgbd_dataset_freiburg1_desk/rgb/";
    std::vector<cv::String> old_name;
    cv::String new_name;
    cv::glob(filepath, old_name);

    if (old_name.empty()) {
        std::cerr << "Oop! That has a false about path.\n";
        return -1;
    }else {
        for (auto pd = old_name.begin(); pd != old_name.end(); ++pd) {
            int index = std::distance(old_name.begin(), pd);
            if(index <= old_name.size() || index > 0) {

                char tmp[4];
                std::sprintf(tmp, "%04d", index);

                new_name = filepath + (cv::String)tmp + ".png";
                std::rename(old_name[index].c_str(), new_name.c_str());
//              上两行可改为如下代码
//              cv::Mat img;
//              img = cv::imread(old_name[index],cv::IMREAD_COLOR);
//              new_name = filepath + (cv::String)tmp + ".png";
//              cv::imwrite(new_name,img);
            }else{
                std::cerr << "Iterator has  overflowed!";
                return -1;
            }
        }
    }

}
