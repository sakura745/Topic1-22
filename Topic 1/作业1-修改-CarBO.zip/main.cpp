#include <iostream>
#include <vector>
#include "opencv2/highgui.hpp"

int main(int argc, char** argv)
{
    cv::String filepath = "../../rgb/";
    std::vector<cv::String> old_name;
    cv::glob(filepath, old_name);//将图片导入一个容器内

    if (!old_name.empty())
    {
        for (auto &i : old_name)
        {
            cv::Mat img = cv::imread(i, 1);//设置一个调用imwrite函数的一个参数

            if (i.find(".png") != cv::String::npos)
            {
                char new_name[100];//设置一个sprint的参数
                sprintf(new_name, "%04ld.png", &i - &old_name[0]);
                cv::imwrite(filepath + (cv::String) new_name, img);
            }
            else
            {
                std::cerr << "That has a false about path.\n" << std::endl;
                return -1;
            }
        }
        std::cout << "Changed succeed!\n";
    }
}
